const TelegramBot = require('node-telegram-bot-api'); //code  by RudosS 
const fs = require('fs'); //code  by RudosS 
const token = 'Token bot'; //code  by RudosS 
const bot = new TelegramBot(token, {polling: true}); //code  by RudosS 

let users = {};

const levels = ['ordinary', 'rare', 'super rare', 'semi epic', 'epic', 'semi legendary', 'legendary', 'ultra legendary', 'impossible', 'temple legend', 'temple legend']; //code  by RudosS 

function saveData() {
    fs.writeFileSync('data.json', JSON.stringify(users)); //code  by RudosS 
}

function loadData() {
    try {
        const data = fs.readFileSync('data.json');
        users = JSON.parse(data);
    } catch (e) {
        console.log('No data file found, starting with empty data'); //code  by RudosS 
    }
}

loadData();

bot.onText(/\/start/, (msg) => { //code  by RudosS 
    const chatId = msg.chat.id; //code  by RudosS 
    if (!users[chatId]) { //code  by RudosS 
        users[chatId] = { //code  by RudosS 
            carrots: 60, //code  by RudosS 
            lastFarmVisit: null, //code  by RudosS 
            countryBalls: {
                ukraine: {level: 0, amount: 0}, //code  by RudosS 
                canada: {level: 0, amount: 0}, //code  by RudosS 
                usa: {level: 0, amount: 0}, //code  by RudosS 
                turkey: {level: 0, amount: 0} //code  by RudosS 
            }
        };
        saveData();
    }
    const opts = {
        reply_markup: JSON.stringify({
            keyboard: [
                ['Office🛅', 'Farm👨‍🌾'],
                ['Roulette💫']
            ]
        })
    };
    bot.sendMessage(chatId, 'Welcome to the menu!', opts);
});

bot.on('message', (msg) => {
    const chatId = msg.chat.id;
    if (msg.text === 'Office🛅') {
        let message = `You${users[chatId].carrots} packs of carrots.\n`;
        for (let country in users[chatId].countryBalls) {
            message += `У вас ${users[chatId].countryBalls[country].amount} ${country} мячей уровня ${levels[users[chatId].countryBalls[country].level]}.\n`;
        }
        bot.sendMessage(chatId, message);
    } else if (msg.text === 'Farm👨‍🌾') {
        const now = new Date();
        if (!users[chatId].lastFarmVisit || now - new Date(users[chatId].lastFarmVisit) > 24 * 60 * 60 * 1000) {
            users[chatId].carrots += 60;
            users[chatId].lastFarmVisit = now;
            saveData();
            bot.sendMessage(chatId, `You have collected 60 packs of carrots. Now you have ${users[chatId].carrots} packs of carrots.`);
        } else {
            bot.sendMessage(chatId, `You have already visited the farm today. Please come back in ${Math.ceil((24 * 60 * 60 * 1000 - (now - new Date(users[chatId].lastFarmVisit))) / (60 * 60 * 1000))} hours.`);
        }
    } else if (msg.text === 'Roulette💫') {
        if (users[chatId].carrots >= 30) {
            users[chatId].carrots -= 30;
            const countries = ['ukraine', 'canada', 'usa', 'turkey'];
            const countryIndex = Math.floor(Math.random() * countries.length);
            const country = countries[countryIndex];
            const levelIndex = Math.floor(Math.random() * levels.length);
            users[chatId].countryBalls[country].amount++;
            users[chatId].countryBalls[country].level = levelIndex;
            saveData();
            bot.sendMessage(chatId, `You won ${country} level ball ${levels[levelIndex]}!`);
        } else {
            bot.sendMessage(chatId, `You don't have enough carrots to play roulette. You need to have at least 30 packs of carrots.`);
        }
    }
});









































































//code  by RudosS 
//code  by RudosS
//code  by RudosS 
//code  by RudosS 
//code  by RudosS 
//code  by RudosS 
//code  by RudosS 
//code  by RudosS 
//code  by RudosS 
//code  by RudosS 
//code  by RudosS 
//code  by RudosS 
//code  by RudosS 
